import UIKit
import Foundation

public func solution(_ S: inout String) -> String{
     var musicResult = 0
    var imagesResult = 0
    var moviesResult = 0
    var otherResult = 0
    var solutionString : String = " "
     var files = [String : Int]()
    files["music"] = 0
    files["images"] = 0
    files["movies"] = 0
    files["other"] = 0
    if  S.count > 1 {
        let music = ["mp3", "aac","flac"]
        let images = ["jpg","bmp", "gif"]
        let movies = ["mp4","avi", "mkv"]
        let fileWithSizes: Array = S.split(separator:"\n")
         for i in fileWithSizes {
            let indexs = i.lastIndex(of: ".") ?? i.startIndex
              let indexsub = i.index(after: indexs)
            let end = i.index(i.startIndex, offsetBy: i.count)
            let fileWithSize = i[indexsub..<end]
            let str  = fileWithSize.split(separator: " ")
          
            if music.contains(String(str.first!)) {
                musicResult += Int((String(str[1])).filter("01234567890.".contains))!
              files["music"] = musicResult
               
            }else if images.contains(String(str.first!)) {
                imagesResult += Int((String(str[1])).filter("01234567890.".contains))!
               files["images"] = imagesResult
                
            }else if movies.contains(String(str.first!)) {
                moviesResult += Int((String(str[1])).filter("01234567890.".contains))!
                files["movies"] = moviesResult
               
            }else{
                otherResult +=  Int((String(str[1])).filter("01234567890.".contains))!
              files["other"] = otherResult
                
            }
            
        }
       let  result = (files.compactMap({ (key, value) -> String in
            return "\(key) \(value)"
        }) as Array)
        solutionString = result.joined(separator: "\n")
       
}
return solutionString
    
}

var cArray: String = "my.song.mp3 11b\n" + "my.song.mp3 11b\n" + "my.song.mp3 11b\n" + "greatSong.flac 1000b\n"
    + "not3.txt 5b\n" + "video.mp4 200b\n" + "video.mp4 200b\n" + "video.mp4 200b\n" + "game.exe 100b\n"
    + "mov!e.mkv 10000b" + "mar.jpg 200b\n"
//var cArray: String = "my.song.mp3 11b\n"
print(solution(&cArray))

